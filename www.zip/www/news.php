>> Unique Features:

-7.4 Features: No Protection zone on boats and carpet. Spells, vocations and spells formuled based on Tibia 7.4. There is no Hotkleys!
-War System.
-Cast System.
-Anti Clone.
-Party Sharing Experience. You can share experience in-party with your friends, and receive 10% bonus experience when actived (!share).
-No runes on Shop. They must be conjured.
-Edited Charged Runes. You conjure runes with more charges then real tibia (eg. Sd 2x).
-Fast Soul Regen.
-Conjure Runes on your backpack. You can leave blank rune on your backpack to conjure them.
-Loot message on screen.
-Do not have Wands/Rods, Burst Arrowns based on magic level.

>> Vocation Features:

-Paladins conjure more ammunition. (eg. exevo con = 15 arrows)
-Mages conjure more runes. (eg. adori vita vis = 2 SDs)
-Spears no not break.
-Blank Rune conjuring: You can create blank rune using "adori blank" words.
-Damage increased by 10% for Knights and Paladins.
-Attack speed increased by 10% for all vocations.

>> NPCs:

-They do not sell runes.
-You can buy backpack of mana fluid using the words: "buy bp mf"
-You can buy backpack of life fluid using the words: "buy bp lf"
-Djinns in ankrahmun (DONT NEED THE QUEST)
-Eremo sells amulet of loss.

>> Game Features:

-Bank system.
-Auto-stack items: Items like gold will be automatically grouped.
-Full HP and MP at level up.
-Stone Skin Amulet not avaiable on shop or NPCs, you need to drop them from Warlock or Hydra.

>> Extra Information:

-Real Tibia map: Full real Tibia map, incluiding all NPCs, Port Hope, monsters and quests. -POI quest with all rooms.
-Demon Oak Quest.
-Uptime: 24 hours a day, 7 days a week.
-Team: Dedicated team, ready to give you the proper support.
-You: We want you as a player! Your opinions, advice and / or complaints will be welcome in our forums..