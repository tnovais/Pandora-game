<?
header ("Location: ../index.php");
?>
